<p align="center">
<img src=https://i.ibb.co/fkXKKHH/dnsnew.jpg" alt="20210103-132024" border="0">
</p>
<p align="center">
<a href="https://github.com/denisputraa">
</p>

  
## Things I Code With
<p>
    <img
        src="https://img.shields.io/badge/node.js%20-%2343853D.svg?&style=for-the-badge&logo=node.js&logoColor=white" />
    <img
        src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />



## Clone This Project

```bash
> git clone https://github.com/denisputraa/dnsbot
```

```bash
> cd dnsbot
> bash install.sh
```

### Usage
```bash
> node index.js
```


## Special Thanks To
* [`Fxc7`](https://github.com/Fxc7)
* [`DIM5`](https://github.com/D1M5-DARKBOT)
* [`Mhankbarbar`](https://github.com/MhankBarBar)


## Sosmed
* [`YouTube`](https://youtube.com/channel/UCdAlsvg9B6llWCWV8JMNhug)
* [`WhatsApp`](https://chat.whatsapp.com/Hpwp8FBfJMtHEN5KeuFJKw)
* [`Instagram`](https://instagram.com/denssptraa)
